  var app = angular.module('myApp', []);
  
  
  
  
  
	app.controller('categorycontroller', function($scope, $http) {
		alert("ang ");
		 $http({
			    method : 'GET',
			    url : 'http://localhost:8080/project/getAllCategory'
			   }).then(function successCallback(response) {
			   $scope.users = response.data;
				
			   }, function errorCallback(response) {
			    console.log(response.statusText);
			   });
	});
