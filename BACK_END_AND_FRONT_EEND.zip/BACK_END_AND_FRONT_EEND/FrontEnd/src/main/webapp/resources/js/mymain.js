$(document).ready(function(){
	
    alert("READY fun ");
	
	$("#signup").click(function(){
        
		$("#id02").css({"display":"block"});
		$("#id01").css({"display":"none"});
		
    });
	
	
   $("#login").click(function(){
      	$("#id02").css({"display":"none"});
		$("#id01").css({"display":"display"});
			
    });
		
	
   $("#catList").hover(function()
{
   	   $.ajax({
			type    : "GET",
			url     : "getAllCategory",
			cache   : false,
			data    : "",
			success : function(result){
				
				$("#catList").html(result);
				
			},
			error : function(e)
			{
				
				$("#getResultDiv").html("<strong>Error</strong>"+e);
				console.log("ERROR from Error : ", e[0]);
			}
		});
   	   
			
   });
	
   
   
   
   

   $("#suppList").hover(function()
{
   	   $.ajax({
			type    : "GET",
			url     : "getAllSupplier",
			cache   : false,
			data    : "",
			success : function(result){
				
				$("#suppList").html(result);
				
			},
			error : function(e)
			{
				
				$("#getResultDiv").html("<strong>Error</strong>"+e);
				console.log("ERROR from Error : ", e[0]);
			}
		});
   	   
			
   });
	
   
   
   
   
   
   
	
});