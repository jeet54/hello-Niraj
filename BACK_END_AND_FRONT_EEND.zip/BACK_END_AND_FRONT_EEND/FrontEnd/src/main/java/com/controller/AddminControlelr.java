package com.controller;

import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import java.sql.*;
import javax.servlet.http.HttpServletResponse;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.servlet.ModelAndView;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;


//import com.DAOPattern.*;
// import com.hibernate.HibernateImp;
import com.daoImpl.*;
import com.model.*;
import com.dao.*;

@Controller
public class AddminControlelr    {
	
	static SupplierDao supplierdao = new SupplierDaoImpl();
	static UserDao userdao = new UserDaoImpl();
	
	
	@RequestMapping("/")
	public <HttpServletRequest> ModelAndView home(HttpServletRequest request, HttpServletResponse response)
	{	
		 
		System.out.println(" First Request      ");
		ModelAndView mv = new ModelAndView();
		mv.setViewName("index");
		return mv;
	}
	
	@RequestMapping("/loginvalidate")
	public ModelAndView loginvalidate(HttpServletRequest request, HttpServletResponse response)
	{
		
		String USERMAIL = request.getParameter("USERMAIL");
		String USERPASSWORD = request.getParameter("USERPASSWORD");
		
	     List list = userdao.checkEmail(USERMAIL,USERPASSWORD);
	     
	     Boolean flag =(Boolean) list.get(0);
	     User user = (User)list.get(1);
	     
	     
	     
	     if(flag == true)
	     {
	    	 System.out.println("***************************");
	    	 System.out.println("You are  a valid user");
	    	 System.out.println("***************************");
	    	 
	     }
	     else
	     {

	    	 System.out.println("==============================");
	    	 System.out.println("You are not a valid user");
	    	 System.out.println("==============================");
	    	 
	    	 
	     }
		
		
		/* Important Code for get all data from table */
		
	     /*
		
		System.out.println(" seelct *  from suer ");
		System.out.println(USERMAIL + "   " + USERPASSWORD );
		
		
		List list = userdao.getAllUser();
		
		Iterator item = list.iterator();
		
		while(item.hasNext())
		{
		     User u  = (User)item.next();
		    // u.show(u);
		     
		     
		     if(u.getUserEmail().equals(USERMAIL) && u.getUserPassword().equals(USERPASSWORD))
		     {
		    	 System.out.println(" This is valid user ");
		     }
		     else
		     {
		    	 System.out.println(" This is not a  valid user ");
		    	 
		     }
		     
		 
		}
	
		*/
		
		ModelAndView mv = new ModelAndView();
		mv.setViewName("index");
		try
		{
		request.setAttribute("email",user.getUserEmail());
		}
		catch(Exception e)
		{
			request.setAttribute("email",null);
		}
	
		return mv;

	}
	


	@RequestMapping("/userregister")
	public ModelAndView userregister(HttpServletRequest request, HttpServletResponse response)
	{
	
			String USERMAIL= request.getParameter("USERMAIL");
		
		String USERADDRESS=request.getParameter("USERADDRESS");
		boolean USERENABLED=false;
		String USERNAME=request.getParameter("USERNAME");
		String USERPASSWORD= request.getParameter("USERPASSWORD");
		String USERPHONE = request.getParameter("USERPHONE");
		String USERROLE="userrole";
		
		
		
		
		
		 User user = new User(USERMAIL,USERPASSWORD, USERADDRESS,USERENABLED,
				USERNAME,USERPHONE, USERROLE );
		
		
		 userdao.insertUser(user);
		
				
		ModelAndView mv = new ModelAndView();
		mv.setViewName("registerDemo");
		
		
		
		
		
		return mv;
	}
	
	
	
	
	@RequestMapping("/supplier")
	public ModelAndView supplier(HttpServletRequest request, HttpServletResponse response)
	{
	
		int strid   = Integer.parseInt( request.getParameter("suppid"));
		String strname  =  request.getParameter("suppname");
		
		
		
		
		
		Supplier supplier= new Supplier(strid, strname);
		supplierdao.insertSupplier(supplier);
		
		
		//obj.main(str);
		/*
		int id = Integer.parseInt(strid);
		Supplier curdata = new Supplier(id,strname);
		supplierDao.insertSupplier(curdata);
		
		
		
		System.out.println(strid);
		System.out.println(strname);
		
		
		

	      //print all students
	      for (Supplier supplier : supplierDao.getAllStudents()) {
	         System.out.println("supplier: [ID : " + supplier.getSuppname()  + ", Name : " + supplier.getSuppname() + " ]");
	      }


     
		Connection conn=null;
		Statement st;
		

		try
		{
		
			
			
					
			
			
		    Class.forName ("org.h2.Driver");
		    conn = DriverManager.getConnection ("jdbc:h2:~/test", "sa","niit");
		    st =   conn.createStatement();
		    
		    String sql = "insert into SupplierTable values("+id+",'"+strname +"')";
		    st.executeUpdate(sql);
		    
		    
		    System.out.println("Driver Configured ");
		    System.out.println("and connected  ");
		    System.out.println("statement created    ");
		    System.out.println("data inserted   ");
		    
		    conn.close();
		    
		
		}
		catch(Exception e)
		{
			System.out.println(e);
			
		}
		*/
		
		ModelAndView mv = new ModelAndView();
		mv.setViewName("registerDemo");
		
		return mv;
	}
	
	
	
	@RequestMapping("/getAllSupplier")
	public @ResponseBody ModelAndView  getAllSupplier(HttpServletRequest request, HttpServletResponse response)
	{
		
		System.out.println(" GET ALL Supplier ");
		
		SupplierDao supplierDao = new SupplierDaoImpl();
		List<Supplier> supplist = supplierDao.getAllSupplier();
	
		List ll = new ArrayList();
		
		Iterator item = supplist.iterator();
		while(item.hasNext())
		{
			Supplier l = (Supplier)item.next();
			ll.add(l.getSupplierId());
		}
		
		
		
		ModelAndView mv = new ModelAndView("suppdata");
		
		request.setAttribute("supplist1",ll);	
	
	
		
		
		return mv;
	
		
	}

	
	
	

	//************************   Product ***********************************  
	
	
	
	
	@RequestMapping("/product")
	public ModelAndView product(HttpServletRequest request, HttpServletResponse response)
	{
	
		
		
		String productId   =  request.getParameter("productId");
		String productName  =  request.getParameter("productName");
		
		
		
		System.out.println("Product " + productId + "  " + productName + "  Controller is Working ");
		
		
		
		
		
		ModelAndView mv = new ModelAndView();
		mv.setViewName("registerDemo");
		
		
	
		
		return mv;
	}
	
	
	
	
//****************************************
	

	
	
	//************************   Product ***********************************  
	
	
	
	
	@RequestMapping("/category")
	public ModelAndView category(HttpServletRequest request, HttpServletResponse response)
	{
	

		int strid   = Integer.parseInt(request.getParameter("categoryid"));
		String strname  =  request.getParameter("categoryname");
		
		
		Category category = new Category(strid,strname);
		
		CategoryDaoImpl categoryDaoImpl = new CategoryDaoImpl();
		categoryDaoImpl.insertCategory(category);
		

		
		
		System.out.println("category " + strid + "  " + strname + "  Controller is Working ");
		
				
		ModelAndView mv = new ModelAndView();
		mv.setViewName("registerDemo");
		
		return mv;
	}
	
	
	
	
	
	@RequestMapping("/getAllCategory")
	public @ResponseBody ModelAndView  getAllCategory(HttpServletRequest request, HttpServletResponse response)
	{
		
		System.out.println(" NIIT GET ALL");
		
		CategoryDao categoryDao = new CategoryDaoImpl();
		List<Category> catlist = categoryDao.getAllCategory();
	
		List ll = new ArrayList();
		
		Iterator item = catlist.iterator();
		while(item.hasNext())
		{
			Category l = (Category)item.next();
			ll.add(l.getCategoryId());
		}
		
		
		
		ModelAndView mv = new ModelAndView("catdata");
		
		request.setAttribute("catlist1",ll);	
	
	
		
		
		return mv;
	
		
	}

	
	
	
//****************************************

	
	@RequestMapping("/login")
	public ModelAndView login(HttpServletRequest request, HttpServletResponse response)
	{
			
		ModelAndView mv = new ModelAndView();
		mv.setViewName("login");
		return mv;
	}
	
	
	
	
	// This is for getting data directly form the H2 Data base 
	// Event it is not being used in this project
	// Only for the DEMO 
	
	
	@RequestMapping("/loggedin")
	public ModelAndView loggedin(HttpServletRequest request, HttpServletResponse response)
	{
	
		
		
		Connection conn=null;
		Statement st=null;
		ResultSet rs=null;
		String msg="loginerror";
		
		ModelAndView mv = new ModelAndView();
		

		try
		{
			
			String strname   =  request.getParameter("username");
			String strpass   =  request.getParameter("pass");
			
			System.out.println(strname + "   " +  strpass);
			
			
			
		
		    Class.forName ("org.h2.Driver");
		    conn = DriverManager.getConnection ("jdbc:h2:~/test", "sa","niit");
		    st =   conn.createStatement();
		    
		    
		    
		    
		    String sql = "select * from NIITUSER where username = '" + strname + "' and pass='"+strpass+"'";
		    
		    rs = st.executeQuery(sql);
		    
		    rs.next();
		  
		    	
		   String su =  	rs.getString(1) ;
		   String sp =      rs.getString(4);

		   System.out.println("  Data from the Database  ");
		   System.out.println(su + "   " +  sp);
		   
		   
		   
		   
		    
			System.out.println(strname  +  "    "  +  strpass);
			
			
			
			conn.close();
			
			
			if(strname.equals(su) && strpass.equals(sp))
			{
				
				
				msg="loginsuccess";
				
			}
			else
			{
			
				msg="loginerror";
			
				
			}
			
			
			
		    
		 
		    
		
		}
		catch(Exception e)
		{
			System.out.println(e);
			
		}
		
		
		mv.setViewName(msg);
		return mv;
	}
		
	
	
	
	
	
	
	
}
