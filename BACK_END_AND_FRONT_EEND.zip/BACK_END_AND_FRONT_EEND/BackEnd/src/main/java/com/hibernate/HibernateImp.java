package com.hibernate;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.cfg.Configuration;

import com.model.Supplier;

public class HibernateImp {
	
	 static SessionFactory sessionFactory=null;
	public static void main(String[] args) {

		System.out.println("Main is Functinaling after update ");

		getHibernateSessionFactory();

	}

	public static SessionFactory getHibernateSessionFactory()
	{
		
		Configuration cfg = new Configuration();
	     
		cfg.configure("hibernate.cfg.xml");
		
		SessionFactory firstsessionFactory = cfg.buildSessionFactory();
		
		System.out.println(" hibernate.cfg.xml  File Found and configured " );
		
		
		
		
		
		  sessionFactory = new Configuration().configure().buildSessionFactory();
	   // return sessionFactory;
		  
		  return firstsessionFactory;
		
	}
	
	

}
