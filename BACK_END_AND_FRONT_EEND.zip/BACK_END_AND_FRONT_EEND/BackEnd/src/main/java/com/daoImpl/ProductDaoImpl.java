package com.daoImpl;

import java.util.List;

import com.dao.ProductDao;
import com.model.Product;

public class ProductDaoImpl implements ProductDao {

	public List<Product> getAllProduct() {
		// TODO Auto-generated method stub
		return null;
	}

	public Product getProduct(int productId) {
		// TODO Auto-generated method stub
		return null;
	}

	public void insertProduct(Product product) {
		// TODO Auto-generated method stub
		
	}

	public void updateProduct(Product product) {
		// TODO Auto-generated method stub
		
	}

	public void deleteProduct(Product product) {
		// TODO Auto-generated method stub
		
	}

}
