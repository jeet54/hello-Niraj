package com.daoImpl;

import com.model.Category;
import com.model.User;

import java.util.List;
import org.hibernate.Session;
import org.hibernate.Transaction;

import com.dao.CategoryDao;
import com.hibernate.HibernateImp;

public class CategoryDaoImpl implements CategoryDao
{
	
	
	
	
	 public CategoryDaoImpl()
	 {
	 
	 }
	

	public List<Category> getAllCategory() {
		
		
		System.out.println(" getAll from BackEND ");
		
		java.util.List <Category>list=null;
		try
		{
		 // creating session object
        Session session = HibernateImp.getHibernateSessionFactory().openSession();

        // creating transaction object
        Transaction t = session.beginTransaction();
        
        
        
        //Query query = session.createQuery("FROM USER ");
        
         list = (List<Category>) session.createQuery("from Category").list();
        System.out.println(list);
        t.commit();
        session.close();
        
        System.out.println("No Error  IN Category  ");
		}
		catch(Exception e)
		{
			System.out.println("Error in Category   "+e);
			
		}
		
		return list;
	}

	public Category getCategory(int categoryId) {
		// TODO Auto-generated method stub
		return null;
	}

	public void insertCategory(Category category) {
			
		try 
		{
			
			System.out.println("  category  id  "+ category.getCategoryId());
			System.out.println("  category Name "+ category.getCategoryName());
			
			
			
			
			Session session = HibernateImp.getHibernateSessionFactory().openSession();
			session.beginTransaction();
			session.save(category);
			session.getTransaction().commit();
			System.out.println(" Data stored in Category");

		} catch (Exception e) {
			System.out.println("error " + e);

		}
		
		
		
	}

	public void updateCategory(Category category) {
		// TODO Auto-generated method stub
		
	}

	public void deleteCategory(Category Category) {
		// TODO Auto-generated method stub
		
	}

}
