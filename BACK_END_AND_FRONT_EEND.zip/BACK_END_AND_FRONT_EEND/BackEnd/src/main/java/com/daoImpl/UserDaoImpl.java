package com.daoImpl;

import java.util.ArrayList;
import java.util.List;

import org.hibernate.Session;
import org.hibernate.Transaction;
import org.hibernate.criterion.Restrictions;
import org.hibernate.Criteria;
import org.hibernate.Query;

import com.dao.UserDao;
import com.hibernate.HibernateImp;
import com.model.User;

public class UserDaoImpl implements UserDao{
	
	
	
	public List checkEmail(String userEmail,String userPassword)
	{
		
		List l = new ArrayList();
		
		 Session session = HibernateImp.getHibernateSessionFactory().openSession();

		boolean flag=false;
		User user=null;
		 try {
	Criteria criteria = session.createCriteria(User.class)
	                    .add(Restrictions.and(Restrictions.eq("userEmail", userEmail),Restrictions.eq("userPassword", userPassword)));
	            

	            
	            Object result = criteria.uniqueResult();
	            
	            
	            if (result != null) 
	            {
	            	flag = true;
	                 user = (User) result;
	                System.out.println("Email = " + user.getUserEmail());
	                System.out.println("Address = " + user.getUserAddress());
	                System.out.println("Name  = " + user.getUserName());
	                System.out.println("Password = " + user.getUserPassword());
	                System.out.println("Phone = " + user.getUserPhone());
	                System.out.println("Role = " + user.getUserRole());
	                
	                
	            }
	        } finally {
	            session.close();
	        }
		
		 l.add(flag);
		 l.add(user);
		 
		return l;
		
	}

	public List<User> getAllUser() {
		
		java.util.List <User>list=null;
		try
		{
		 // creating session object
        Session session = HibernateImp.getHibernateSessionFactory().openSession();

        // creating transaction object
        Transaction t = session.beginTransaction();
        
        
        System.out.println("Before :  From USER  ");
        //Query query = session.createQuery("FROM USER ");
        System.out.println("After :  From USER  ");
         list = (List<User>) session.createQuery("from User").list();
        System.out.println(list);
        t.commit();
        session.close();
		
		
		}
		catch(Exception e11)
		{
			
			System.out.println("Error from UserDaoImpl  "+ e11);

		}
		return list;
		
	}

	public User getUser(String userEmail) {
		// TODO Auto-generated method stub
		return null;
	}

	
	
	
	
	public void insertUser(User user) {
		try 
		{
			
			System.out.println("  user  id  "+ user.getUserEmail());
			System.out.println("  user  Name "+ user.getUserName());
			
			
			Session session = HibernateImp.getHibernateSessionFactory().openSession();
			session.beginTransaction();
			session.save(user);
			session.getTransaction().commit();
			
			
			System.out.println(" Data stored in User Table ");

		} catch (Exception e) {
			System.out.println(" Error in SupplierDaoImpl  " + e);

		}
		
	}

	public void updateUser(User user) {
		// TODO Auto-generated method stub
		
	}

	public void deleteUser(User user) {
		// TODO Auto-generated method stub
		
	}

}
