package com.daoImpl;
import com.model.Category;
import com.model.Supplier;

import java.util.List;

import org.hibernate.Session;
import org.hibernate.Transaction;

import com.dao.SupplierDao;
import com.hibernate.HibernateImp;

public class SupplierDaoImpl implements SupplierDao
{

	public List<Supplier> getAllSupplier() {
		
      System.out.println(" getAll from BackEND: Supplier  ");
		java.util.List <Supplier>list=null;
		
		try
		{
			// creating session object
			Session session = HibernateImp.getHibernateSessionFactory().openSession();
			// creating transaction object
			Transaction t = session.beginTransaction();
			//Query query = session.createQuery("FROM USER ");
         list = (List<Supplier>) session.createQuery("from Supplier").list();
         System.out.println(list);
         t.commit();
        session.close();
        
        System.out.println("No Error  IN Supplier  ");
		}
		catch(Exception e)
		{
			System.out.println("Error in Supplier   "+e);
			
		}
		
		return list;
		
	}

	
	public Supplier getSupplier(int supplierId) {
		// TODO Auto-generated method stub
		return null;
	}

	public void insertSupplier(Supplier supplier) {
		try 
		{
			
			System.out.println("  supplier  id  "+ supplier.getSupplierId());
			System.out.println("  supplier Name "+ supplier.getSupplierName());
			
			
			Session session = HibernateImp.getHibernateSessionFactory().openSession();
			session.beginTransaction();
			session.save(supplier);
			session.getTransaction().commit();
			System.out.println(" Data stored in Supplier");

		} catch (Exception e) {
			System.out.println(" Error in SupplierDaoImpl  " + e);

		}
		
		
	}

	public void updateSupplier(Supplier supplier) {
		// TODO Auto-generated method stub
		
	}

	public void deleteSupplier(Supplier supplier) {
		// TODO Auto-generated method stub
		
	}

}
