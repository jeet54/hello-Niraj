package com.dao;

import java.util.List;

import com.model.Category;
import com.model.Product;
import com.model.Supplier;

public interface ProductDao {
	
	public List<Product> getAllProduct();
	
	   public Product getProduct(int productId);
	   public void insertProduct(Product product);
	   public void updateProduct(Product product);
	   public void deleteProduct(Product product);
	   
	   

}
