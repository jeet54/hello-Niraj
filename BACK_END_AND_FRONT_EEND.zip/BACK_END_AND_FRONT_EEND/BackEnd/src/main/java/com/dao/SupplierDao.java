package com.dao;

import java.util.List;

import com.model.Supplier;

public interface SupplierDao {

		public List<Supplier> getAllSupplier();
		
	   public Supplier getSupplier(int supplierId);
	   public void insertSupplier(Supplier supplier);
	   public void updateSupplier(Supplier supplier);
	   public void deleteSupplier(Supplier supplier);
	   
	   
	
}
