package com.dao;
import java.util.List;

import com.model.Category;

public interface CategoryDao
{
       public List<Category> getAllCategory();
	   public Category getCategory(int categoryId);
	   public void insertCategory(Category category);
	   public void updateCategory(Category category);
	   public void deleteCategory(Category Category);

}
