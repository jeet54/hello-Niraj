package com.dao;

import java.util.List;


import com.model.User;

public interface UserDao {

	
	 public List<User> getAllUser();
	 
	 public User getUser(String userEmail);
	 public void insertUser(User user);
	 public void updateUser(User user);
	 public void deleteUser(User user);
	 public List checkEmail(String userEmail,String userPassword);
	
	
}
