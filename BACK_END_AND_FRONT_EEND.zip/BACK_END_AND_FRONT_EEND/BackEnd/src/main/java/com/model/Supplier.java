package com.model;

import java.util.HashSet;
import java.util.Set;

import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.Id;
import javax.persistence.OneToMany;

@Entity
public class Supplier {

	@Id
	int SupplierId;
	public int getSupplierId() {
		return SupplierId;
	}

	public void setSupplierId(int supplierId) {
		SupplierId = supplierId;
	}

	public String getSupplierName() {
		return SupplierName;
	}

	public void setSupplierName(String supplierName) {
		SupplierName = supplierName;
	}

	String SupplierName ;
	
	public Supplier()
	{
		this.SupplierId=0;
		this.SupplierName=null;
		
	}
	
	public Supplier(int SupplierId, String SupplierName)
	{
		this.SupplierId=SupplierId;
		this.SupplierName=SupplierName;
		
	}
	
	
	@OneToMany(targetEntity=Supplier.class,fetch=FetchType.EAGER,mappedBy="supplier")
	private Set<Supplier> supplier = new HashSet<Supplier>(0);
	public Set<Supplier> getSupplier() {
		return supplier;
	}

	public void setSupplier(Set<Supplier> supplier) {
		this.supplier = supplier;
	}
	
	
	
	
}
