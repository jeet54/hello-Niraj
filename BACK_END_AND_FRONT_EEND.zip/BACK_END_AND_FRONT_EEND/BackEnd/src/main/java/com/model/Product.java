package com.model;

import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Transient;

@Entity
public class Product {
	@Id
	private int productId;
	public int getProductId() {
		return productId;
	}




	public void setProductId(int productId) {
		this.productId = productId;
	}




	public String getProductName() {
		return productName;
	}




	public void setProductName(String productName) {
		this.productName = productName;
	}




	public String getProductDescription() {
		return productDescription;
	}




	public void setProductDescription(String productDescription) {
		this.productDescription = productDescription;
	}




	public Float getProductPrice() {
		return productPrice;
	}




	public void setProductPrice(Float productPrice) {
		this.productPrice = productPrice;
	}




	public Float getProductStock() {
		return productStock;
	}




	public void setProductStock(Float productStock) {
		this.productStock = productStock;
	}




	public String getProductImage() {
		return productImage;
	}




	public void setProductImage(String productImage) {
		this.productImage = productImage;
	}




	public Supplier getSupplier() {
		return supplier;
	}




	public void setSupplier(Supplier supplier) {
		this.supplier = supplier;
	}




	public Category getCategory() {
		return category;
	}




	public void setCategory(Category category) {
		this.category = category;
	}




	private String productName;
	private String productDescription;
	private Float productPrice;
	private Float productStock;
	
	
	
	@Transient
	private String productImage                                                                                                                                                    ;
	
	
	@ManyToOne(fetch=FetchType.EAGER)
	@JoinColumn(name="SupplierId")
	private Supplier supplier;
	
	
	
	
	@ManyToOne(fetch=FetchType.EAGER)
	@JoinColumn(name="categoryId")
	private Category category; 
	
	
	
	
}
