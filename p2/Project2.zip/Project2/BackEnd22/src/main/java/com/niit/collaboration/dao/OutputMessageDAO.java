package com.niit.collaboration.dao;

public interface OutputMessageDAO {

}
