package com.niit.collaboration.model;
public class OutputMessage
{

	public OutputMessage(String from, String text, String time)
	{
		// TODO Auto-generated constructor stub
	}
	

}
