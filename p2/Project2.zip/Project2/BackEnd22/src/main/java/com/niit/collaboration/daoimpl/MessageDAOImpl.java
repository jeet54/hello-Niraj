package com.niit.collaboration.daoimpl;

public interface MessageDAOImpl {

}
