package com.niit.collaboration.daoimpl;

public class OutputMessageDAOImpl {

}
